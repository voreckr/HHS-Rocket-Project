digi\.xbee\.serial module
=========================

.. automodule:: digi.xbee.serial
    :members:
    :inherited-members:
    :show-inheritance:
