#!/bin/bash

set -e
set -x

python3 setup.py bdist_wheel
