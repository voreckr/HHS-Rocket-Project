#!/bin/bash

set -e
set -x

sudo apt-get install -y libasound2-dev
