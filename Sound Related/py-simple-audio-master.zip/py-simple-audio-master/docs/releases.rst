Release Notes
=============

* 1.0.4

   * Added 24-bit and 32-bit playback capability

* 1.0.3

   * Added CI builds of pre-built binaries for Python 3.7 and 3.8, dropped others

* 1.0.2

   * Fixed Linux and Windows thread resource leaks
   * Dropped creation of pre-built binaries for Python 3.3

* 1.0.1

   * Fixed OSX and Linux 8-bit playback

* 1.0.0

   * Initial Release
